import {React, useState} from "react";


const Adduser = () => {

    const [User, setuser] = useState({
        firstname: "",
        lastname: "",
        email: "",
        number: ""
    })


    return(
        <div className="container mt-3">
        <div className='row'>
          <div className='col-md-5'>
          <h1 className='my-5 font-weight-bold-display-4'>Add Details</h1>
          <form onSubmit={e => onsubmit(e)}>
          <div class="mb-3">
    <label htmlFor="exampleInputEmail1" className="form-label">First Name</label>
    <input type="text" name="first_name" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
          </div>        
          <div className="mb-3">
    <label htmlFor="exampleInputEmail1" className="form-label">Last Name</label>
    <input type="text" name="last_name" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
          </div> 
  <div className="mb-3">
    <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
    <input type="email" name="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
    <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div className="mb-3">
    <label htmlFor="exampleInputPassword1" className="form-label">Number</label>
    <input type="number" name="number" className="form-control" id="exampleInputPassword1" 
    onChange={e => oninputChange(e)}
    />
  </div>
  <button type="submit" className="btn btn-primary">Submit</button>
</form>
          </div>
         <div className="col-md-3">
             <img className='img-fluid w-100 mt-5' src='https://cdn2.vectorstock.com/i/1000x1000/31/61/cartoon-man-with-laptop-vector-12133161.jpg'/>
         </div>
        </div>
        </div>
    );
}

export default Adduser;