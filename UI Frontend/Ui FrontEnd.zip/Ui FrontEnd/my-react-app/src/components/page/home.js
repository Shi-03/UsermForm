import React from 'react';

 const Home = () => {
    return(
        <div className='container mt-5'>
            <h3 className='mb-5'>User Registration List</h3>
            <table class="table">
  <thead class="table-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email</th>
      <th scope="col">Number</th>
      <th scope="col" className='bg-danger' >Action</th>
      
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</table>
        </div>
    );
}
export default Home;