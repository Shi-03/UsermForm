import React from 'react';


 const About = () => {
    return(
        <div>
            <h1 className='container mt-5'>About
            </h1>
            <p className='container'>
            Where does it come from?
Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
Morbi sollicitudin nunc non est lacinia mollis. Vivamus consequat massa metus. Ut dignissim mauris vitae scelerisque vestibulum. Phasellus eleifend odio ligula, at rhoncus mi imperdiet sollicitudin. Nullam non hendrerit nisi. Aenean commodo dolor sit amet ligula feugiat tempus. Sed mi lorem, viverra sed est quis, imperdiet malesuada dui. Nunc commodo nulla id dolor auctor, quis semper turpis blandit. Aenean laoreet, turpis a rhoncus dictum, eros lorem posuere nisl, in faucibus elit elit eu leo. Sed libero turpis, scelerisque at lectus non, dignissim rhoncus ipsum. Nullam in risus nec nisl pellentesque pulvinar eu varius metus. Praesent maximus hendrerit vestibulum. Nunc feugiat laoreet cursus.

Sed sed ante aliquet, pellentesque nisl at, rhoncus lacus. Proin eu felis auctor, vehicula orci nec, tristique tellus. Duis id mollis metus. Nullam condimentum metus semper libero imperdiet, eu efficitur nunc tincidunt. Integer eget lacus a augue faucibus egestas eget et ipsum. Sed egestas justo justo, a porttitor eros dignissim a. Donec dui mauris, facilisis eu justo at, congue condimentum orci. Nam dolor eros, mollis eget iaculis quis, consectetur a ante. Phasellus volutpat gravida porta. Vivamus blandit viverra lectus. Curabitur in nibh ut augue pellentesque convallis in nec augue. Morbi ultricies suscipit lorem, id tristique ante convallis sed. Curabitur eget nunc eu nulla viverra tristique a et mauris. Aliquam pharetra auctor posuere. Suspendisse hendrerit egestas velit, ac porttitor mi posuere pretium. Maecenas ac eros et nunc vulputate dignissim et at nisl.

Maecenas pharetra rutrum mi, hendrerit vestibulum tellus tristique non. Curabitur lacinia tellus at magna aliquet, non elementum mi volutpat. Donec finibus enim ut odio tristique mattis. Sed at libero vehicula, posuere quam et, interdum enim. Quisque ornare, nulla non cursus gravida, ex lectus sagittis tortor, et faucibus augue tortor ac turpis. In hac habitasse platea dictumst. Duis ut ultricies ligula, nec tempor est. Ut nisi mauris, luctus ac massa fringilla, blandit dictum enim.
            </p>
        </div>
    );
}

export default About;