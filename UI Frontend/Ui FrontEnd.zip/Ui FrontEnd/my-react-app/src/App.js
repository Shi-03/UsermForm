import './App.css';
import Home from './components/page/home';
import About from './components/page/About';
import Contect from './components/page/contect';
import Navbar from './components/Layout/Navbar';
import Adduser from './components/Addusers/Addusers';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';






function App() {
  return (
   <Router>
    <div className='app'>
      <Navbar />
      <Routes>
        <Route exact path='/home' element={<Home />}></Route>
        <Route exact path='/about' element={<About />}></Route>
        <Route exact path='/contect' element={<Contect />}></Route>
        <Route exact path='/addusers' element={<Adduser />}></Route>
      </Routes>
    </div>
   </Router>
  );
}

export default App;